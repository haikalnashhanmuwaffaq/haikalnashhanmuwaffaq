<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'db_kkp';

// Membuat koneksi
$connect = mysqli_connect($host, $username, $password, $database);

// Memeriksa koneksi
if (!$connect) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
